#coding=utf-8
import glob
import requests
import shutil
import os
import json
from multiprocessing import Pool

def try_request(url,headers,try_times=10):
    t = 0
    while t<try_times:
        try:
            #print(t,'try:',url)
            r = requests.get(url,headers=headers,timeout=30)
        except Exception:
            t+=1
            if t==try_times:
                raise Exception("timeout")
        else:
            break
    return r


def download_image(url,save_path):
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36',
        'accept':'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
     }
    r = try_request(url,headers)
    with open(save_path,'wb') as f:
        f.write(r.content)
    print(f'Download:{url},save_path:{save_path}')

def download_item_images(json_file,save_path):
    data = json.load(open(json_file))
    img_urls = data['img_urls']
    for img_url in img_urls:
        filename = img_url.split('/')[-1]
        if not filename.endswith('.jpg') and not filename.endswith('.png') and not filename.endswith('.JPG'):
            filename =filename+'.jpg'
        file_save_path = os.path.join(save_path,filename)
        os.makedirs(save_path,exist_ok=True)
        download_image(img_url,file_save_path)

def download_category_images(category_dir,save_path):
    pattern = os.path.join(category_dir,'*.json')
    for json_file in glob.glob(pattern):
        item_id = os.path.split(json_file)[-1].split('.')[0]
        item_save_path = os.path.join(save_path,item_id)
        download_item_images(json_file,item_save_path)

def download_all(metrictree_dir,save_path):
    pattern = os.path.join(metrictree_dir,'*')
    pool = Pool(32)
    for category_dir in glob.glob(pattern):
        category = os.path.split(category_dir)[-1]
        category_save_path = os.path.join(save_path,category)
        pool.apply_async(download_category_images,args=(category_dir,category_save_path))
        #download_category_images(category_dir,category_save_path)
    pool.close()
    pool.join()
    

def main():
    metrictree_dir = '../metrictree'
    save_path = './metrictree_images'
    download_all(metrictree_dir,save_path)

if __name__ == '__main__':
    main()