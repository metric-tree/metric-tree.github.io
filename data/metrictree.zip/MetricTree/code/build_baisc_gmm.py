#coding=utf-8
import json
import os
import glob
import numpy as np
from sklearn.mixture import BayesianGaussianMixture as GMM


def read_category_sizes(category_dir):
    pattern = os.path.join(category_dir,'*.json')
    width,depth,height = [],[],[]
    full = []
    for file in glob.glob(pattern):
        data = json.load(open(file))
        width.append([data['dimension']['width']])
        depth.append([data['dimension']['depth']])
        height.append([data['dimension']['height']])
        full.append([data['dimension']['width'],data['dimension']['depth'],data['dimension']['height']])

    return [width,depth,height,full]

def filter(data):
    new_data = []
    for d in data:
        has_none = False
        for dd in d:
            if dd is None:
                has_none=True
                break
        if not has_none:
            new_data.append(d)

    return new_data

def build_gmm(category_dir,split_dimension_build=False):
    dimensions = read_category_sizes(category_dir)
    if split_dimension_build:
        width,depth,height,_ = dimensions
        width = filter(width)
        depth = filter(depth)
        height = filter(height)
        w_n = len(width)//3
        d_n = len(depth)//3
        h_n = len(height)//3
        w_GMM = GMM(n_components=w_n,max_iter=1000).fit(width) if w_n>0 else None
        d_GMM = GMM(n_components=d_n,max_iter=1000).fit(depth) if d_n>0 else None
        h_GMM = GMM(n_components=h_n,max_iter=1000).fit(height) if h_n>0 else None
        return [w_GMM,d_GMM,h_GMM]
    else:
        _,_,_,full = dimensions
        full = filter(full)
        f_n = len(full)//3
        f_GMM = GMM(n_components=f_n,max_iter=1000).fit(full) if f_n>0 else None
        return f_GMM



def main():
    category_dir = '../metrictree/woman'
    _,_,h_GMM = build_gmm(category_dir,split_dimension_build=True)
    


if __name__ == '__main__':
    main()






